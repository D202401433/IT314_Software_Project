'use client';

import React from 'react';
import { Header } from '@/components/Header';
import { BhuvanMap } from '@/components/BhuvanMap';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-[#0F172A]">
      <Header />
      <main className="flex-1 flex flex-col overflow-hidden">
        <BhuvanMap />
      </main>
    </div>
  );
}
