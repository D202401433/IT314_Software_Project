'use client';

import React from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import { useAuth } from '@/context/AuthContext';
import {
  ShieldCheckIcon,
  CheckCircleIcon,
  RadioIcon,
  KeyIcon,
  ActivityIcon,
} from '@/components/icons';

export default function AdminWorkspace() {
  const { demoAccounts } = useAuth();

  return (
    <WorkspaceLayout
      title="Platform Governance & Security Audit Console"
      subtitle="MeitY / NDMA Compliance Cell • RBAC Policies, Cryptographic Audit Logs & System Health"
      allowedRoles={['ADMINISTRATOR']}
      badgeColor="bg-purple-800"
    >
      <div className="space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Audit Hash Chain</span>
            <div className="text-2xl font-black text-emerald-600 mt-1 flex items-baseline justify-between">
              <span>Verified 100%</span>
              <span className="text-xs font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">SHA-256 Tamper-Proof</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">RBAC Roles Defined</span>
            <div className="text-2xl font-black text-[#1976D2] mt-1 flex items-baseline justify-between">
              <span>7 Roles</span>
              <span className="text-xs font-mono text-blue-600 bg-blue-50 px-2 py-0.5 rounded">BCNF Normalized</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Active Agency Sessions</span>
            <div className="text-2xl font-black text-slate-800 mt-1 flex items-baseline justify-between">
              <span>128 Terminals</span>
              <span className="text-xs font-mono text-gray-600 bg-gray-100 px-2 py-0.5 rounded">Token Revocation Ready</span>
            </div>
          </div>
        </div>

        {/* Demo & Test Accounts Registry */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between border-b pb-3 mb-4">
            <div className="flex items-center gap-2">
              <KeyIcon className="w-5 h-5 text-purple-700" />
              <h2 className="text-sm font-bold text-gray-900">
                Authorized Emergency Personnel Accounts Directory
              </h2>
            </div>
            <span className="text-xs font-mono text-gray-500">Security Level: RESTRICTED</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-gray-50 text-gray-500 font-mono border-b">
                <tr>
                  <th className="py-2.5 px-3">Role / Appointment</th>
                  <th className="py-2.5 px-3">Agency</th>
                  <th className="py-2.5 px-3">Official Identifier</th>
                  <th className="py-2.5 px-3">Target Workspace</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {demoAccounts.map((acc) => (
                  <tr key={acc.identifier} className="hover:bg-gray-50">
                    <td className="py-2.5 px-3 font-bold text-gray-900">{acc.roleTitle}</td>
                    <td className="py-2.5 px-3 text-gray-600">{acc.agency}</td>
                    <td className="py-2.5 px-3 font-mono text-blue-700">{acc.identifier}</td>
                    <td className="py-2.5 px-3 font-mono text-gray-500">{acc.targetWorkspace}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-800">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
