'use client';

import React from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import { SAMPLE_INCIDENTS } from '@/components/BhuvanMap';
import {
  ShieldCheckIcon,
  MapPinIcon,
  RadioIcon,
  ActivityIcon,
  CheckCircleIcon,
  TruckIcon,
  AmbulanceIcon,
  FlameIcon,
} from '@/components/icons';

export default function DispatcherWorkspace() {
  return (
    <WorkspaceLayout
      title="Operational GIS & Command Dispatch Console"
      subtitle="Incident Response System (NDMA / IRS) • State Emergency Operations Centre"
      allowedRoles={['COMMAND_OFFICER', 'DISPATCHER', 'ADMINISTRATOR']}
      badgeColor="bg-red-700"
    >
      <div className="space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Active Triage Queue</span>
            <div className="text-2xl font-black text-red-600 mt-1 flex items-baseline justify-between">
              <span>7 Incidents</span>
              <span className="text-xs font-mono text-red-500 bg-red-50 px-2 py-0.5 rounded">2 Level 1 Crit</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Dispatched Units</span>
            <div className="text-2xl font-black text-[#1976D2] mt-1 flex items-baseline justify-between">
              <span>18 Teams</span>
              <span className="text-xs font-mono text-blue-500 bg-blue-50 px-2 py-0.5 rounded">6 NDRF Bns</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Mean Triage Latency</span>
            <div className="text-2xl font-black text-emerald-600 mt-1 flex items-baseline justify-between">
              <span>3.8s</span>
              <span className="text-xs font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">&lt; 10s NFR-1</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">ERSS 112 Ingestion</span>
            <div className="text-2xl font-black text-[#1F2937] mt-1 flex items-baseline justify-between">
              <span>4,120 Calls/hr</span>
              <span className="text-xs font-mono text-amber-600 bg-amber-50 px-2 py-0.5 rounded">Spike +380%</span>
            </div>
          </div>
        </div>

        {/* Operational Dispatch Action Grid */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ActivityIcon className="w-4 h-4 text-[#1976D2]" />
              <h2 className="text-sm font-bold text-gray-900">
                IRS Priority Triage Queue (Gujarat Coastal & Urban Sectors)
              </h2>
            </div>
            <Link
              href="/"
              className="text-xs text-[#1976D2] hover:underline font-semibold flex items-center gap-1"
            >
              <RadioIcon className="w-3.5 h-3.5" />
              Switch to Fullscreen Bhuvan GIS Map
            </Link>
          </div>

          <div className="divide-y divide-gray-200">
            {SAMPLE_INCIDENTS.map((inc) => (
              <div key={inc.id} className="p-4 hover:bg-gray-50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        inc.severity === 'CRITICAL'
                          ? 'bg-red-100 text-red-800 border border-red-200'
                          : inc.severity === 'HIGH'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-blue-100 text-blue-800 border border-blue-200'
                      }`}
                    >
                      {inc.severity}
                    </span>
                    <span className="font-mono text-xs text-gray-500">{inc.code}</span>
                    <span className="text-xs font-bold text-amber-600 ml-auto md:ml-2">
                      IRS Priority: {inc.priorityScore}/100
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-gray-900">{inc.title}</h3>
                  <p className="text-xs text-gray-600 mt-1">{inc.description}</p>
                  <div className="flex flex-wrap items-center gap-4 mt-2 text-[11px] text-gray-500">
                    <span className="flex items-center gap-1">
                      <MapPinIcon className="w-3.5 h-3.5 text-gray-400" />
                      {inc.location}
                    </span>
                    <span>Reported: {inc.reportedTime}</span>
                    <span className="text-blue-600 font-medium">Assigned: {inc.assignedAgencies.join(', ')}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Link
                    href="/"
                    className="px-3 py-1.5 bg-[#1976D2] hover:bg-[#0D47A1] text-white text-xs font-semibold rounded shadow transition-colors"
                  >
                    View on Map
                  </Link>
                  <button
                    onClick={() => alert(`Operational command acknowledge for incident ${inc.code}. Tactical unit alerted.`)}
                    className="px-3 py-1.5 border border-gray-300 hover:bg-gray-100 text-gray-700 text-xs font-medium rounded transition-colors"
                  >
                    Acknowledge
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
