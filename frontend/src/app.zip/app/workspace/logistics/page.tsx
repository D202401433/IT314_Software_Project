'use client';

import React from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import {
  TruckIcon,
  CheckCircleIcon,
  RadioIcon,
  MapPinIcon,
} from '@/components/icons';

export default function LogisticsWorkspace() {
  return (
    <WorkspaceLayout
      title="Civil Relief Supplies & Logistics Dispatch Portal"
      subtitle="State Civil Supplies & Warehousing • Food, Water, Shelter Kits & Convoy Tracking"
      allowedRoles={['LOGISTICS_OFFICER', 'ADMINISTRATOR']}
      badgeColor="bg-teal-700"
    >
      <div className="space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Ration Packs Dispatched</span>
            <div className="text-2xl font-black text-emerald-600 mt-1 flex items-baseline justify-between">
              <span>32,000 Packs</span>
              <span className="text-xs font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Surat & Kutch</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Relief Convoys in Transit</span>
            <div className="text-2xl font-black text-[#1976D2] mt-1 flex items-baseline justify-between">
              <span>8 Convoys</span>
              <span className="text-xs font-mono text-blue-600 bg-blue-50 px-2 py-0.5 rounded">GPS Monitored</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Tarpaulin & Shelter Kits</span>
            <div className="text-2xl font-black text-slate-800 mt-1 flex items-baseline justify-between">
              <span>12,500 Kits</span>
              <span className="text-xs font-mono text-gray-600 bg-gray-100 px-2 py-0.5 rounded">Stock 85%</span>
            </div>
          </div>
        </div>

        {/* Warehouse Status */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between border-b pb-3 mb-4">
            <div className="flex items-center gap-2">
              <TruckIcon className="w-5 h-5 text-teal-600" />
              <h2 className="text-sm font-bold text-gray-900">
                Regional Disaster Relief Supply Warehouses
              </h2>
            </div>
            <Link href="/" className="text-xs text-[#1976D2] hover:underline font-semibold flex items-center gap-1">
              <RadioIcon className="w-3.5 h-3.5" />
              View Locations on Map
            </Link>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-gray-900 block">Gandhinagar Central Emergency Warehouse (SEOC)</span>
                <span className="text-gray-500 text-[11px]">Supplying Saurashtra coastal relief corridors</span>
              </div>
              <span className="font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded font-bold">
                Operational Ready
              </span>
            </div>

            <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-gray-900 block">Surat Municipal Flood Relief Depot</span>
                <span className="text-gray-500 text-[11px]">Supplying 42 stranded flood communities along Tapi basin</span>
              </div>
              <span className="font-mono text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded font-bold">
                Active Convoy Loading
              </span>
            </div>
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
