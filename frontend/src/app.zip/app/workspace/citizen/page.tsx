'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import {
  ShieldCheckIcon,
  MapPinIcon,
  AlertTriangleIcon,
  CheckCircleIcon,
  RadioIcon,
  PhoneIcon,
  InfoIcon,
} from '@/components/icons';

export default function CitizenWorkspace() {
  const [reportSubmitted, setReportSubmitted] = useState<boolean>(false);
  const [incidentType, setIncidentType] = useState<string>('URBAN_FLOODING');
  const [location, setLocation] = useState<string>('Surat Rander Road, Gujarat');
  const [description, setDescription] = useState<string>('');

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    setReportSubmitted(true);
  };

  return (
    <WorkspaceLayout
      title="Citizen Emergency Services & Reporting Workspace"
      subtitle="Public Incident Reporting • Safety Bulletins • Relief Tracking (ERSS 112)"
      allowedRoles={['CITIZEN', 'ADMINISTRATOR']}
      badgeColor="bg-emerald-600"
    >
      <div className="space-y-6">
        {/* Top Emergency Advisory Callout */}
        <div className="p-4 bg-red-50 border-l-4 border-red-600 rounded-r-xl shadow-sm text-xs text-red-900 flex items-start gap-3">
          <AlertTriangleIcon className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-sm block">Active Regional Advisory: Gujarat Coastal Cyclone Alert Level 3</span>
            <span>
              If you are in immediate life danger, please dial <strong>112 (ERSS)</strong> or <strong>1070 (SEOC)</strong> directly. For stranded family members, submit a geo-tagged incident report below.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Report Incident Form */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <h2 className="text-base font-bold text-gray-900 mb-1 flex items-center gap-2">
              <MapPinIcon className="w-5 h-5 text-[#1976D2]" />
              Report Local Emergency / Request Rescue
            </h2>
            <p className="text-xs text-gray-500 mb-4">
              Your submission is instantly parsed by our Indic GenAI Triage Engine and forwarded to the nearest NDRF/108 EMS command hub.
            </p>

            {reportSubmitted ? (
              <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircleIcon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-emerald-900">Distress Report Submitted to SEOC</h3>
                <p className="text-xs text-emerald-800 max-w-md mx-auto">
                  Incident reference ID: <strong className="font-mono">CIT-GJ-{Math.floor(1000 + Math.random() * 9000)}</strong>. Dispatched responders have received your coordinates. Keep your phone line free.
                </p>
                <button
                  onClick={() => {
                    setReportSubmitted(false);
                    setDescription('');
                  }}
                  className="px-4 py-2 bg-[#1976D2] hover:bg-[#0D47A1] text-white text-xs font-semibold rounded shadow transition-colors"
                >
                  Submit Another Report
                </button>
              </div>
            ) : (
              <form onSubmit={handleReportSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Incident Scenario</label>
                    <select
                      value={incidentType}
                      onChange={(e) => setIncidentType(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-md text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#1976D2]"
                    >
                      <option value="URBAN_FLOODING">Urban Flooding / Waterlogging</option>
                      <option value="CYCLONE">Cyclone Storm Surge / Tree Collapse</option>
                      <option value="INDUSTRIAL_FIRE">Industrial Fire / Chemical Leak</option>
                      <option value="MEDICAL_EMERGENCY">Medical Emergency / Ambulance Required</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Location / Landmark</label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-md text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#1976D2]"
                      placeholder="Street, Landmark, Ward, City"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Describe Emergency & Number of People Affected
                  </label>
                  <textarea
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Provide details: water level, elderly/children trapped, medical assistance needed, etc. (Supports English, Hindi, and Gujarati)"
                    className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-md text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#1976D2]"
                    required
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-[11px] text-gray-500 font-mono flex items-center gap-1">
                    <InfoIcon className="w-3.5 h-3.5" />
                    GPS Coordinates auto-tagged: 21.1702° N, 72.8311° E
                  </span>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-md shadow transition-colors flex items-center gap-2"
                  >
                    <ShieldCheckIcon className="w-4 h-4" />
                    Transmit Emergency SOS
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: Published Safety Content & Advisories (NU-FR-08) */}
          <div className="space-y-4">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
              <h3 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                <ShieldCheckIcon className="w-4 h-4 text-[#1976D2]" />
                Official NDMA Safety SOPs
              </h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <span className="font-bold text-blue-900 block mb-0.5">Cyclone Safety Protocol</span>
                  <p className="text-blue-800 leading-relaxed text-[11px]">
                    Stay indoors away from windows. Disconnect electrical appliances. Move to designated storm shelters if in low-lying coastal zones.
                  </p>
                </div>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <span className="font-bold text-amber-900 block mb-0.5">Flash Flood Protocol</span>
                  <p className="text-amber-800 leading-relaxed text-[11px]">
                    Move to higher floors immediately. Do not attempt to walk or drive through moving water. Avoid contact with downed power lines.
                  </p>
                </div>
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <span className="font-bold text-red-900 block mb-0.5">Industrial Fire Protocol</span>
                  <p className="text-red-800 leading-relaxed text-[11px]">
                    Evacuate upwind of smoke plumes. Cover nose and mouth with a damp cloth. Await hazardous material fire response.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 text-center">
              <span className="text-xs font-semibold text-gray-600 block mb-2">Want to monitor active regional maps?</span>
              <Link
                href="/"
                className="w-full inline-flex items-center justify-center gap-2 py-2 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold rounded transition-colors"
              >
                <RadioIcon className="w-4 h-4 text-[#1976D2]" />
                Return to Public GIS Map
              </Link>
            </div>
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
