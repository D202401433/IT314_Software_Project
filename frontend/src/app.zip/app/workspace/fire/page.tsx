'use client';

import React from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import {
  FlameIcon,
  ActivityIcon,
  RadioIcon,
  MapPinIcon,
  AlertTriangleIcon,
} from '@/components/icons';

export default function FirefighterWorkspace() {
  return (
    <WorkspaceLayout
      title="Fire & Hazardous Materials Response Portal"
      subtitle="Gujarat State Fire Command • Aerial Hazmat Plumes, Wind Vectors & Tender Fleet"
      allowedRoles={['FIREFIGHTER', 'ADMINISTRATOR']}
      badgeColor="bg-amber-700"
    >
      <div className="space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Active Fire Incidents</span>
            <div className="text-2xl font-black text-amber-600 mt-1 flex items-baseline justify-between">
              <span>2 Locations</span>
              <span className="text-xs font-mono text-red-600 bg-red-50 px-2 py-0.5 rounded">1 Major Chemical</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Deployed Fire Tenders</span>
            <div className="text-2xl font-black text-[#1976D2] mt-1 flex items-baseline justify-between">
              <span>14 Vehicles</span>
              <span className="text-xs font-mono text-blue-600 bg-blue-50 px-2 py-0.5 rounded">Foam & Hydraulic</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Wind Vector Telemetry</span>
            <div className="text-2xl font-black text-slate-800 mt-1 flex items-baseline justify-between">
              <span>24 km/h WSW</span>
              <span className="text-xs font-mono text-amber-600 bg-amber-50 px-2 py-0.5 rounded">Plume Drift 1.8km</span>
            </div>
          </div>
        </div>

        {/* Tactical Hazmat Overview */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between border-b pb-3 mb-4">
            <div className="flex items-center gap-2">
              <FlameIcon className="w-5 h-5 text-amber-600" />
              <h2 className="text-sm font-bold text-gray-900">
                Live Toxic Plume Dispersion — Vatva Industrial Zone
              </h2>
            </div>
            <Link href="/" className="text-xs text-[#1976D2] hover:underline font-semibold flex items-center gap-1">
              <RadioIcon className="w-3.5 h-3.5" />
              Inspect on Bhuvan GIS Map
            </Link>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-2">
            <div className="flex items-center gap-2 font-bold text-sm text-amber-800">
              <AlertTriangleIcon className="w-4 h-4 text-amber-700" />
              <span>Downwind Gas Dispersion Advisory Active</span>
            </div>
            <p>
              Drone aerial thermal imaging detected benzene-solvent fire core reaching 820°C. Foam mist suppression active. Evacuation corridor along NH-48 secured.
            </p>
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
