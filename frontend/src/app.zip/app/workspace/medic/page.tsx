'use client';

import React from 'react';
import Link from 'next/link';
import { WorkspaceLayout } from '@/components/WorkspaceLayout';
import {
  AmbulanceIcon,
  ActivityIcon,
  CheckCircleIcon,
  AlertTriangleIcon,
  MapPinIcon,
  RadioIcon,
} from '@/components/icons';

export default function MedicWorkspace() {
  return (
    <WorkspaceLayout
      title="Field Medic & Emergency Triage Portal"
      subtitle="108 GVK-EMRI Network • Patient Vitals, Casualty Queue & Hospital Bed Tracking"
      allowedRoles={['FIELD_MEDIC', 'ADMINISTRATOR']}
      badgeColor="bg-rose-700"
    >
      <div className="space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Casualties in Triage</span>
            <div className="text-2xl font-black text-red-600 mt-1 flex items-baseline justify-between">
              <span>65 En Route</span>
              <span className="text-xs font-mono text-red-600 bg-red-50 px-2 py-0.5 rounded">18 Priority Red</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">Active 108 Ambulances</span>
            <div className="text-2xl font-black text-emerald-600 mt-1 flex items-baseline justify-between">
              <span>24 Units</span>
              <span className="text-xs font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">GPS Tracked</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <span className="text-xs text-gray-500 font-semibold block uppercase">ICU Bed Availability</span>
            <div className="text-2xl font-black text-[#1976D2] mt-1 flex items-baseline justify-between">
              <span>38 Beds</span>
              <span className="text-xs font-mono text-blue-600 bg-blue-50 px-2 py-0.5 rounded">Civil Hospital AHD</span>
            </div>
          </div>
        </div>

        {/* Triage Queue Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AmbulanceIcon className="w-5 h-5 text-rose-600" />
              <h2 className="text-sm font-bold text-gray-900">
                Active Hospital Emergency Receiving Status
              </h2>
            </div>
            <Link href="/" className="text-xs text-[#1976D2] hover:underline font-semibold flex items-center gap-1">
              <RadioIcon className="w-3.5 h-3.5" />
              View on Bhuvan Map
            </Link>
          </div>

          <div className="p-4 space-y-3">
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-xs text-red-900 block">Civil Hospital Ahmedabad — Trauma Center</span>
                <span className="text-[11px] text-red-700">Admitting from Vatva Chemical Blaze • 12 Burn Casualties Admitted</span>
              </div>
              <span className="text-xs font-mono font-bold text-red-800 bg-red-100 px-2.5 py-1 rounded">
                ICU: 8 Beds Left
              </span>
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-xs text-blue-900 block">New Civil Hospital Surat (Majura Gate)</span>
                <span className="text-[11px] text-blue-700">Receiving Tapi River Flood Rescued • 28 Patients Stable</span>
              </div>
              <span className="text-xs font-mono font-bold text-blue-800 bg-blue-100 px-2.5 py-1 rounded">
                General: 45 Beds Left
              </span>
            </div>
          </div>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
