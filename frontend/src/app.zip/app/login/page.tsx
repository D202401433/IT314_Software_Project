'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { AccountType, getRoleDefaultPath, DemoAccount } from '@/types/auth';
import { Header } from '@/components/Header';
import {
  ShieldCheckIcon,
  UserIcon,
  LockIcon,
  EyeIcon,
  EyeOffIcon,
  ArrowLeftIcon,
  AlertTriangleIcon,
  KeyIcon,
} from '@/components/icons';

function BhuvanLoginContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { login, isAuthenticated, user, demoAccounts } = useAuth();

  const typeParam = searchParams.get('type');
  const initialType: AccountType =
    typeParam === 'citizen' ? 'citizen' : typeParam === 'admin' ? 'admin' : 'agency';
  const redirectParam = searchParams.get('redirect') || searchParams.get('returnUrl');

  // Form State
  const [accountType, setAccountType] = useState<AccountType>(initialType);
  const [identifier, setIdentifier] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Validation & Submission States
  const [errors, setErrors] = useState<{ identifier?: string; password?: string; general?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showCitizenRegisterModal, setShowCitizenRegisterModal] = useState<boolean>(false);
  const [showDemoModal, setShowDemoModal] = useState<boolean>(false);

  // If already authenticated, redirect to workspace
  useEffect(() => {
    if (isAuthenticated && user) {
      const destination = redirectParam || getRoleDefaultPath(user.role);
      router.push(destination);
    }
  }, [isAuthenticated, user, router, redirectParam]);

  // Handle Tab Switch
  const handleTabSwitch = (type: AccountType) => {
    setAccountType(type);
    setErrors({});
    setIdentifier('');
    setPassword('');
  };

  // Pre-fill from Demo Account Drawer
  const handleSelectDemoAccount = (demo: DemoAccount) => {
    setAccountType(demo.accountType);
    setIdentifier(demo.identifier);
    setPassword(demo.password);
    setErrors({});
    setShowDemoModal(false);
  };

  // Form validation
  const validateForm = (): boolean => {
    const newErrors: { identifier?: string; password?: string } = {};

    if (!identifier.trim()) {
      if (accountType === 'citizen') {
        newErrors.identifier = 'Mobile number or email address is required.';
      } else if (accountType === 'admin') {
        newErrors.identifier = 'Administrator ID or official email is required.';
      } else {
        newErrors.identifier = 'Employee ID or official email is required.';
      }
    } else if (accountType === 'citizen') {
      const isEmail = identifier.includes('@');
      const isPhone = /^[0-9+\s-]{8,15}$/.test(identifier.trim());
      if (!isEmail && !isPhone) {
        newErrors.identifier = 'Please provide a valid 10-digit mobile number or email.';
      }
    } else if (identifier.trim().length < 3) {
      newErrors.identifier = 'Identifier must be at least 3 characters.';
    }

    if (!password) {
      newErrors.password = 'Password is required to authenticate.';
    } else if (password.length < 4) {
      newErrors.password = 'Password must be at least 4 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!validateForm()) return;

    setIsSubmitting(true);
    setErrors({});

    try {
      const result = await login(
        {
          identifier: identifier.trim(),
          password,
          accountType,
        },
        rememberMe
      );

      if (result.success && result.user) {
        const destination = redirectParam || getRoleDefaultPath(result.user.role);
        router.push(destination);
      } else {
        setErrors({
          general:
            result.error ||
            'Authentication failed. Please verify your credentials and try again.',
        });
      }
    } catch {
      setErrors({
        general: 'A connection error occurred while communicating with the authentication authority.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FFFFFF] flex flex-col justify-between font-sans text-white">
      {/* ========================================================= */}
      {/* 1. COMPACT SOLID BLUE HEADER (Deep Navy Blue #0D47A1)      */}
      {/* ========================================================= */}
      <Header variant="login" />

      {/* ========================================================= */}
      {/* 2. COMFORTABLY LARGE CENTERED LOGIN CARD (Deep Navy #0D47A1)*/}
      {/* ========================================================= */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-[700px] bg-[#0D47A1] border-t-4 border-t-[#BBF7D0] border-x border-b border-[#60A5FA] rounded-lg shadow-2xl p-6 sm:p-10 text-white">
          
          {/* Card Top Title & ResQ AI Logo */}
          <div className="flex items-center gap-3.5 mb-6 pb-4 border-b border-[#60A5FA]/40">
            <div className="w-10 h-10 rounded bg-[#1976D2] border border-[#60A5FA] flex items-center justify-center text-[#BBF7D0] shadow-sm shrink-0">
              <ShieldCheckIcon className="w-6 h-6 text-[#BBF7D0]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white leading-tight">
                Welcome to ResQ AI
              </h1>
              <p className="text-xs sm:text-sm text-blue-100 leading-none mt-1">
                Sign in to access your workspace.
              </p>
            </div>
          </div>

          {/* Exactly 3 Account Types: Agency Personnel, Public / Citizen, Administration */}
          <div className="mb-5">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#BBF7D0] mb-2">
              Select Account Type
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Option 1: Agency Personnel */}
              <button
                type="button"
                id="tab-agency"
                onClick={() => handleTabSwitch('agency')}
                className={`h-11 px-3 rounded text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 border transition-colors ${
                  accountType === 'agency'
                    ? 'bg-[#15803D] text-white border-[#BBF7D0] shadow-sm'
                    : 'bg-white text-[#0D47A1] border-[#60A5FA] hover:bg-[#BBF7D0] hover:text-[#15803D]'
                }`}
                aria-selected={accountType === 'agency'}
                role="tab"
              >
                <ShieldCheckIcon className={`w-4 h-4 shrink-0 ${accountType === 'agency' ? 'text-white' : 'text-[#0D47A1]'}`} />
                <span className="truncate">Agency Personnel</span>
              </button>

              {/* Option 2: Public / Citizen */}
              <button
                type="button"
                id="tab-citizen"
                onClick={() => handleTabSwitch('citizen')}
                className={`h-11 px-3 rounded text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 border transition-colors ${
                  accountType === 'citizen'
                    ? 'bg-[#15803D] text-white border-[#BBF7D0] shadow-sm'
                    : 'bg-white text-[#0D47A1] border-[#60A5FA] hover:bg-[#BBF7D0] hover:text-[#15803D]'
                }`}
                aria-selected={accountType === 'citizen'}
                role="tab"
              >
                <UserIcon className={`w-4 h-4 shrink-0 ${accountType === 'citizen' ? 'text-white' : 'text-[#0D47A1]'}`} />
                <span className="truncate">Public / Citizen</span>
              </button>

              {/* Option 3: Administration */}
              <button
                type="button"
                id="tab-admin"
                onClick={() => handleTabSwitch('admin')}
                className={`h-11 px-3 rounded text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 border transition-colors ${
                  accountType === 'admin'
                    ? 'bg-[#15803D] text-white border-[#BBF7D0] shadow-sm'
                    : 'bg-white text-[#0D47A1] border-[#60A5FA] hover:bg-[#BBF7D0] hover:text-[#15803D]'
                }`}
                aria-selected={accountType === 'admin'}
                role="tab"
              >
                <KeyIcon className={`w-4 h-4 shrink-0 ${accountType === 'admin' ? 'text-white' : 'text-[#0D47A1]'}`} />
                <span className="truncate">Administration</span>
              </button>
            </div>
          </div>

          {/* Account-Specific Information Badges */}
          {accountType === 'agency' && (
            <div className="mb-5 px-3.5 py-2.5 bg-[#082959] border border-[#60A5FA] rounded text-xs text-blue-100 flex items-center justify-between">
              <span className="flex items-center gap-2 font-medium">
                <ShieldCheckIcon className="w-4 h-4 text-[#BBF7D0]" />
                Authorized personnel only.
              </span>
              <span className="text-[11px] font-mono text-[#BBF7D0] font-semibold bg-[#15803D]/60 px-2 py-0.5 rounded border border-[#BBF7D0]/40">
                SEOC / NDRF
              </span>
            </div>
          )}

          {accountType === 'citizen' && (
            <div className="mb-5 px-3.5 py-2.5 bg-[#082959] border border-[#60A5FA] rounded text-xs text-blue-100 leading-relaxed">
              <span className="font-semibold block mb-0.5 text-[#BBF7D0]">Public Emergency Reporting</span>
              <span className="text-[11.5px] text-blue-200">
                Emergency reporting availability depends on active regional disaster declaration. Dial 112 for direct dispatch.
              </span>
            </div>
          )}

          {accountType === 'admin' && (
            <div className="mb-5 px-3.5 py-2.5 bg-[#082959] border border-[#60A5FA] rounded text-xs text-blue-100 flex items-center justify-between">
              <span className="flex items-center gap-2 font-medium">
                <LockIcon className="w-4 h-4 text-[#BBF7D0]" />
                Authorized administrators only.
              </span>
              <span className="text-[11px] font-mono text-[#BBF7D0] font-semibold bg-[#15803D]/60 px-2 py-0.5 rounded border border-[#BBF7D0]/40">
                Governance Cell
              </span>
            </div>
          )}

          {/* Error Banner */}
          {errors.general && (
            <div
              className="mb-5 p-3.5 bg-red-50 border-l-4 border-[#DC2626] text-[#DC2626] text-xs sm:text-sm flex items-start gap-2.5 rounded-r"
              role="alert"
            >
              <AlertTriangleIcon className="w-5 h-5 shrink-0 mt-0.5 text-[#DC2626]" />
              <div className="flex-1">
                <span className="font-bold block">Authentication Failure</span>
                <span>{errors.general}</span>
              </div>
              <button
                type="button"
                onClick={() => setErrors((prev) => ({ ...prev, general: undefined }))}
                className="text-[#DC2626] hover:text-red-900 text-sm font-bold"
              >
                ✕
              </button>
            </div>
          )}

          {/* Main Form */}
          <form onSubmit={handleSubmit} noValidate className="space-y-4 sm:space-y-5">
            {/* Identifier input */}
            <div>
              <label htmlFor="identifier-input" className="block text-xs sm:text-sm font-semibold text-white mb-1.5">
                {accountType === 'citizen'
                  ? 'Mobile Number or Email'
                  : accountType === 'admin'
                  ? 'Administrator ID or Official Email'
                  : 'Employee ID or Official Email'}
                <span className="text-[#BBF7D0] ml-1">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#0D47A1]">
                  {accountType === 'citizen' ? (
                    <UserIcon className="w-4 h-4 text-[#0D47A1]" />
                  ) : accountType === 'admin' ? (
                    <KeyIcon className="w-4 h-4 text-[#0D47A1]" />
                  ) : (
                    <ShieldCheckIcon className="w-4 h-4 text-[#0D47A1]" />
                  )}
                </div>
                <input
                  id="identifier-input"
                  type="text"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    if (errors.identifier) setErrors((prev) => ({ ...prev, identifier: undefined }));
                  }}
                  placeholder={
                    accountType === 'citizen'
                      ? 'e.g. 9876543210 or citizen@resq.in'
                      : accountType === 'admin'
                      ? 'e.g. ADMIN-0001 or admin@drch.gov.in'
                      : 'e.g. SEOC-0112 or ops@seoc.gov.in'
                  }
                  disabled={isSubmitting}
                  className={`w-full pl-10 pr-3.5 py-2.5 text-xs sm:text-sm bg-white border border-[#60A5FA] rounded text-[#1F2937] placeholder-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-[#BBF7D0] focus:border-[#1976D2] ${
                    errors.identifier ? 'ring-2 ring-red-400 border-red-500' : ''
                  }`}
                />
              </div>
              {errors.identifier && (
                <p className="mt-1 text-xs text-[#BBF7D0] font-medium leading-tight">
                  {errors.identifier}
                </p>
              )}
            </div>

            {/* Password input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="password-input" className="block text-xs sm:text-sm font-semibold text-white">
                  Password <span className="text-[#BBF7D0]">*</span>
                </label>
                <Link
                  href="/forgot-password"
                  className="text-xs text-[#BBF7D0] hover:text-white font-semibold hover:underline"
                >
                  Forgot Password?
                </Link>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#0D47A1]">
                  <LockIcon className="w-4 h-4 text-[#0D47A1]" />
                </div>
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                  }}
                  placeholder="Enter your security password"
                  disabled={isSubmitting}
                  className={`w-full pl-10 pr-10 py-2.5 text-xs sm:text-sm bg-white border border-[#60A5FA] rounded text-[#1F2937] placeholder-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-[#BBF7D0] focus:border-[#1976D2] ${
                    errors.password ? 'ring-2 ring-red-400 border-red-500' : ''
                  }`}
                />
                <button
                  type="button"
                  id="toggle-password-visibility"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-[#0D47A1] focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-xs text-[#BBF7D0] font-medium leading-tight">
                  {errors.password}
                </p>
              )}
            </div>

            {/* Remember Me Checkbox & Citizen Register link */}
            <div className="flex items-center justify-between text-xs sm:text-sm pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-white">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  disabled={isSubmitting}
                  className="w-4 h-4 text-[#15803D] border-[#60A5FA] rounded focus:ring-[#BBF7D0]"
                />
                <span className="text-xs sm:text-sm text-blue-100">Remember me on this terminal</span>
              </label>

              {accountType === 'citizen' && (
                <button
                  type="button"
                  onClick={() => setShowCitizenRegisterModal(true)}
                  className="text-xs sm:text-sm text-[#BBF7D0] hover:text-white font-semibold hover:underline"
                >
                  Register as Citizen
                </button>
              )}
            </div>

            {/* Primary Submit Button */}
            <button
              type="submit"
              id="submit-login-button"
              disabled={isSubmitting}
              className="w-full mt-3 py-3 px-4 bg-[#1976D2] hover:bg-[#0D47A1] active:bg-[#082959] text-white text-sm font-semibold rounded shadow-md border border-[#60A5FA] hover:border-[#BBF7D0] transition-colors focus:outline-none focus:ring-2 focus:ring-[#BBF7D0]/50 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <ShieldCheckIcon className="w-4 h-4 text-[#BBF7D0]" />
                  <span>
                    {accountType === 'citizen'
                      ? 'Sign In as Citizen'
                      : accountType === 'admin'
                      ? 'Sign In to Administration'
                      : 'Sign In to Tactical Workspace'}
                  </span>
                </>
              )}
            </button>
          </form>

          {/* Bottom Actions: Back to Map & Demo Accounts Helper */}
          <div className="mt-6 pt-5 border-t border-[#60A5FA]/40 flex items-center justify-between text-xs sm:text-sm">
            <Link
              href="/"
              className="text-[#BBF7D0] hover:text-white flex items-center gap-1.5 font-semibold transition-colors hover:underline"
            >
              <ArrowLeftIcon className="w-4 h-4 text-[#BBF7D0]" />
              <span>Back to Public Map</span>
            </Link>

            <button
              type="button"
              id="demo-accounts-toggle-btn"
              onClick={() => setShowDemoModal(true)}
              className="text-xs font-semibold text-[#0D47A1] bg-[#BBF7D0] hover:bg-white hover:text-[#0D47A1] border border-[#60A5FA] px-3 py-1.5 rounded transition-colors shadow-sm"
              title="Open Test Credentials"
            >
              Demo Accounts (Test)
            </button>
          </div>
        </div>
      </main>

      {/* ========================================================= */}
      {/* 3. FORMAL GOVERNMENT FOOTER                               */}
      {/* ========================================================= */}
      <footer className="text-center py-3.5 text-xs text-[#0D47A1] font-semibold font-sans border-t border-[#60A5FA]/40 bg-[#FFFFFF]">
        ResQ AI — Disaster Response Coordination Hub
      </footer>

      {/* ========================================================= */}
      {/* CITIZEN REGISTRATION MODAL                                */}
      {/* ========================================================= */}
      {showCitizenRegisterModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl border-2 border-[#60A5FA] max-w-md w-full p-6 text-[#1F2937]">
            <div className="flex items-center justify-between mb-3 border-b border-[#60A5FA]/30 pb-2">
              <div className="flex items-center gap-2">
                <UserIcon className="w-5 h-5 text-[#15803D]" />
                <h4 className="font-bold text-base text-[#0D47A1]">Citizen Registration Portal</h4>
              </div>
              <button
                onClick={() => setShowCitizenRegisterModal(false)}
                className="text-[#64748B] hover:text-[#1F2937] text-sm font-bold"
              >
                ✕
              </button>
            </div>
            <p className="text-xs sm:text-sm text-[#64748B] leading-relaxed mb-4">
              In accordance with ERSS 112 and DPDP Act 2023 regulations, citizen accounts require verified Indian mobile OTP authentication.
            </p>
            <div className="bg-blue-50 border border-[#60A5FA] rounded p-3 text-xs sm:text-sm text-[#0D47A1] mb-4">
              <strong className="text-[#15803D]">Emergency Calling:</strong> Immediate life-threatening calls can dial <strong>112</strong> without registration.
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => {
                  setShowCitizenRegisterModal(false);
                  handleSelectDemoAccount(
                    demoAccounts.find((d) => d.accountType === 'citizen') || demoAccounts[7]
                  );
                }}
                className="px-3.5 py-2 bg-slate-100 hover:bg-[#BBF7D0] text-[#0D47A1] border border-[#60A5FA] rounded text-xs font-semibold"
              >
                Load Citizen Demo
              </button>
              <button
                onClick={() => setShowCitizenRegisterModal(false)}
                className="px-4 py-2 bg-[#1976D2] text-white hover:bg-[#0D47A1] rounded text-xs font-semibold border border-[#60A5FA]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* DEMO ACCOUNTS MODAL (One-Click Pre-fill)                   */}
      {/* ========================================================= */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl border-2 border-[#60A5FA] max-w-2xl w-full p-6 text-[#1F2937] max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 border-b border-[#60A5FA]/30 pb-3">
              <div className="flex items-center gap-2">
                <KeyIcon className="w-5 h-5 text-[#15803D]" />
                <div>
                  <h4 className="font-bold text-base text-[#0D47A1]">
                    Evaluation Demo Accounts (One-Click Pre-fill)
                  </h4>
                  <p className="text-xs text-[#64748B]">
                    Click any role card below to populate credentials and test role-based workspaces.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowDemoModal(false)}
                className="text-[#64748B] hover:text-[#1F2937] text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
              {demoAccounts.map((demo) => (
                <div
                  key={demo.identifier}
                  onClick={() => handleSelectDemoAccount(demo)}
                  className="p-3.5 rounded border border-[#60A5FA] hover:border-[#15803D] hover:bg-[#BBF7D0]/20 cursor-pointer transition-all flex flex-col justify-between group text-xs"
                >
                  <div className="flex items-start justify-between gap-1 mb-1">
                    <span className="font-bold text-[#1F2937] group-hover:text-[#0D47A1] text-sm">
                      {demo.label}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                        demo.accountType === 'citizen'
                          ? 'bg-[#BBF7D0] text-[#15803D] border border-[#15803D]/40'
                          : demo.accountType === 'admin'
                          ? 'bg-[#0D47A1] text-white'
                          : 'bg-[#15803D] text-white'
                      }`}
                    >
                      {demo.role}
                    </span>
                  </div>
                  <p className="text-xs text-[#64748B] truncate mb-2">{demo.agency}</p>
                  <div className="text-xs font-mono text-[#1F2937] bg-[#F1F5F9] px-2.5 py-1.5 rounded flex justify-between border border-[#60A5FA]/60">
                    <span className="truncate">{demo.identifier}</span>
                    <span className="text-[#64748B]">Password@123</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setShowDemoModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-[#0D47A1] border border-[#60A5FA] rounded text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#FFFFFF] flex items-center justify-center">
          <div className="w-8 h-8 border-3 border-[#1976D2]/30 border-t-[#1976D2] rounded-full animate-spin" />
        </div>
      }
    >
      <BhuvanLoginContent />
    </Suspense>
  );
}
