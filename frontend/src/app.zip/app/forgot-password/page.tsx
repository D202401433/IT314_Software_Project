'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  ShieldCheckIcon,
  ArrowLeftIcon,
  AlertTriangleIcon,
  CheckCircleIcon,
  InfoIcon,
} from '@/components/icons';

export default function ForgotPasswordPage() {
  const [identifier, setIdentifier] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const clean = identifier.trim();
    if (!clean) {
      setError('Please provide your Employee ID or registered official email.');
      return;
    }

    if (clean.length < 3) {
      setError('Identifier must be at least 3 characters.');
      return;
    }

    setIsSubmitting(true);
    // Simulate lookup
    await new Promise((res) => setTimeout(res, 600));
    setIsSubmitting(false);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col justify-between">
      {/* Top Header */}
      <header className="w-full bg-[#1976D2] text-white shadow-sm z-30 sticky top-0 h-11 border-b border-[#1565C0]">
        <div className="w-full px-4 sm:px-6 h-full flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-white hover:opacity-90 transition-opacity">
            <div className="w-6 h-6 rounded bg-[#0D47A1] border border-blue-300/30 flex items-center justify-center shrink-0 shadow-sm">
              <ShieldCheckIcon className="w-4 h-4 text-white" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm tracking-tight text-white">ResQ AI</span>
              <span className="text-[10px] text-blue-100 hidden sm:inline border-l border-blue-300/40 pl-2">
                Access Recovery
              </span>
            </div>
          </Link>
          <Link
            href="/login"
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#0D47A1] hover:bg-[#1565C0] text-white text-xs font-semibold rounded border border-blue-300/30 transition-colors shadow-sm"
          >
            <ArrowLeftIcon className="w-3.5 h-3.5" />
            <span>Back to Sign In</span>
          </Link>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-lg bg-[#FFFFFF] rounded-lg shadow-sm border border-[#CBD5E1] p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-4 pb-3 border-b border-[#CBD5E1]">
            <div className="w-10 h-10 rounded bg-[#1976D2] text-[#FFFFFF] flex items-center justify-center shadow-sm">
              <ShieldCheckIcon className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#1F2937]">Password Recovery</h1>
              <p className="text-xs text-[#64748B]">
                Official agency personnel credential verification
              </p>
            </div>
          </div>

          {!submitted ? (
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <p className="text-xs text-[#64748B] leading-relaxed">
                Enter your official government email address or Agency Employee ID associated with your National/State Disaster Management appointment.
              </p>

              <div>
                <label htmlFor="recovery-id" className="block text-xs font-semibold text-[#1F2937] mb-1">
                  Employee ID or Official Email <span className="text-[#DC2626]">*</span>
                </label>
                <input
                  id="recovery-id"
                  type="text"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="e.g. SEOC-0112 or ops@seoc.gov.in"
                  className={`w-full px-3 py-2 text-xs sm:text-sm bg-[#FFFFFF] border rounded text-[#1F2937] placeholder-[#64748B] focus:outline-none focus:ring-1 ${
                    error
                      ? 'border-[#DC2626] focus:ring-red-200'
                      : 'border-[#CBD5E1] focus:border-[#1976D2] focus:ring-[#1976D2]'
                  }`}
                  disabled={isSubmitting}
                />
                {error && <p className="mt-1 text-[11px] text-[#DC2626] font-medium">{error}</p>}
              </div>

              <div className="p-3 bg-[#EAF2FC] border border-[#CBD5E1] rounded text-[#0D47A1] text-xs flex items-start gap-2">
                <InfoIcon className="w-4 h-4 text-[#1976D2] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>Notice (Development Mode):</strong> Active directory and SMTP / Gov-SMS gateways have not been configured for live mail delivery yet.
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-[#1976D2] hover:bg-[#1565C0] active:bg-[#0D47A1] text-[#FFFFFF] text-xs sm:text-sm font-semibold rounded shadow-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Querying Agency Security Directory...</span>
                  </>
                ) : (
                  <span>Request Recovery Verification</span>
                )}
              </button>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-[#EAF2FC] border border-[#CBD5E1] rounded text-[#0D47A1] text-xs leading-relaxed space-y-2">
                <div className="flex items-center gap-2 font-bold text-sm text-[#0D47A1]">
                  <CheckCircleIcon className="w-5 h-5 text-[#1976D2]" />
                  <span>Recovery Request Registered</span>
                </div>
                <p>
                  Identifier: <strong className="font-mono">{identifier}</strong>
                </p>
                <p>
                  <strong>Development System Notice:</strong> Because production SMTP and government SMS gateways are not yet configured in this environment, <em>no automated reset email has been dispatched</em>.
                </p>
                <p className="text-[#1F2937]">
                  For evaluation purposes, all demo accounts use the standard test password: <strong className="font-mono text-[#0D47A1]">Password@123</strong>.
                </p>
                <div className="mt-2 pt-2 border-t border-[#CBD5E1] text-[#64748B]">
                  For emergency credential recovery in active duty, please contact the SEOC Gujarat System Control Desk at <strong>control@seoc.state.gov.in</strong> or ERSS Helpline <strong>1070</strong>.
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setIdentifier('');
                  }}
                  className="text-xs text-[#64748B] hover:text-[#1F2937] font-medium"
                >
                  Verify Another ID
                </button>
                <Link
                  href="/login"
                  className="px-4 py-2 bg-[#1976D2] hover:bg-[#1565C0] text-white text-xs font-semibold rounded shadow-sm transition-colors"
                >
                  Return to Sign In
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="text-center py-3.5 text-xs text-[#64748B] border-t border-[#CBD5E1] bg-[#FFFFFF]">
        ResQ AI Disaster Response Coordination Hub • IT314 Software Project
      </footer>
    </div>
  );
}
